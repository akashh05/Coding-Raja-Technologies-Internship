// services/sampleblogs.services.js

// Assuming you have necessary imports and setup for interacting with your database or external service

module.exports = {
    // Method to fetch sample blogs from the database or external service
    fetchBlogs: async () => {
        // Implement logic to fetch sample blogs
        // Example:
        // const blogs = await blog.find({ category: 'sample' });
        // return blogs;
        return [
            // { title: 'Don Quixote', author: 'Don Quixote', genre: 'Novel', publishedYear: 1605 },
            // { title: 'blog 2', author: 'Author 2', genre: 'Mystery', publishedYear: 2019 },
            // Add more sample blogs as needed
        ];
    },
    
}
