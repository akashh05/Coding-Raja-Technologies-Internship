// controllers/blogController.js

const Blog = require('../models/blog');

exports.updateBlog = async (req, res, next) => {
  try {
    const { blogId } = req.params;
    const { blog_name, cover_image, author_name, genres, blog_link } = req.body;

    // Find the blog post by ID and update its fields
    const updatedBlog = await Blog.findByIdAndUpdate(blogId, {
      blog_name,
      cover_image,
      author_name,
      genres,
      blog_link,
      cover_description
    }, { new: true }); // Set { new: true } to return the updated document

    if (!updatedBlog) {
      // If the blog post with the given ID doesn't exist, return a 404 Not Found error
      return res.status(404).json({ message: 'Blog post not found' });
    }

    // Redirect to the blog post detail page or any other appropriate page
    res.redirect(`/blog/${blogId}`);
  } catch (error) {
    // If an error occurs, pass it to the error handling middleware
    next(error);
  }
};
